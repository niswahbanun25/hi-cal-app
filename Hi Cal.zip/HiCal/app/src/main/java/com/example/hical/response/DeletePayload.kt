package com.example.hical.response

data class DeletePayload(
    var id: String
)